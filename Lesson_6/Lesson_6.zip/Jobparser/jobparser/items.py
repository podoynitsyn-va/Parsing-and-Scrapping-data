# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy
from scrapy.loader.processors import TakeFirst


class JobparserItem(scrapy.Item):
    # # define the fields for your item here like:
    # _id = scrapy.Field()
    # domain = scrapy.Field()
    # vacancy_link = scrapy.Field()
    # vacancy_text = scrapy.Field()
    # salary = scrapy.Field()
    # pass
    _id = scrapy.Field()
    domain = scrapy.Field()
    vacancy_link = scrapy.Field()
    vacancy_text = scrapy.Field(output_processor=TakeFirst())
    salary = scrapy.Field()
